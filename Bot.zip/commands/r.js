const config = require(`../config.json`);

module.exports.run = async (bot, message, args, ops) => {
  if (message.author.id !== ops.owner) return message.channel.send('Im sorry, but you are my owner');

  if (!args || args.size < 1) return message.channel.send('Enter the name of the team!');

  try {
    delete require.cache[require.resolve(`./${args[0]}.js`)];
  } catch (e) {
    return message.channel.send(`Unable to restart: **${args[0]}**`);
  }

  message.reply(`Restart **x-${args[0]}**!`)
}