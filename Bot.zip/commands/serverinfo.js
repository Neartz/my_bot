exports.run = (client, message, args) => {
    const moment = require('moment')
    const Discord = require('discord.js')
    var embed = new Discord.RichEmbed()
    .setAuthor(message.author.username, message.author.avatarURL)
    .addField('👾 Creator', message.guild.owner , true)
    .addField('✏ Name', message.guild.name, true)
    .addField('📆 Create', moment(message.guild.createdAt).format('HH:MM | DD-MM-YY'), true)
    .addField('👬 Users', message.guild.members.size, true)
    .setThumbnail(message.guild.avatarURL)
    .setFooter('Creator Xarazzert')
    .setColor('#cc1414')
    message.channel.send(embed)
}
exports.help = {
    name: 'serverinfo'
}