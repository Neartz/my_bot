exports.run = (client, message, args, bot) => {
    const moment = require('moment')
    const Discord = require('discord.js')
    var embed = new Discord.RichEmbed()
    .setAuthor(message.author.username, message.author.avatarURL)
    .addField('👾 Creator', (`${bot.owner}`), true)
    .addField('✏ Name', client.user.username, true)
    .addField('📆 Create', moment(client.user.createdAt).format('HH:MM | DD-MM-YY'), true)
    .addField('🎛 Ping', Math.floor(client.ping), true)
    .setThumbnail(message.author.avatarURL)
    .addField('🛡 Discord.js', `v${Discord.version}`, true)
    .setFooter('Creator Xarazzert')
    .setColor('#cc1414')
    message.channel.send(embed)
}
exports.help = {
    name: 'botinfo'
}   