exports.run = (client, message, args) => {
    const Discord = require('discord.js')
    var embed = new Discord.RichEmbed()
    .setAuthor(message.author.username, message.author.avatarURL)
    .addField('Want a bot to be on your server? Then click on "**Invite**"', '[**Invite**](https://discordapp.com/oauth2/authorize?client_id=493349585536942082&scope=bot&permissions=8)')
    .addField(`**Maud. teams**🛡`, `Commands for modders`)
    .addField(`(r)estart`, 'Reboots the command')
    .addField(`say`, `Bot writes about his name`)
    .addField(`purge`, 'Deleting messages 1-3000')
    .addField(`Commands about infщ about something🎨`, `Teams for people`)
    .addField('help', 'All the bot commands are written here.')
    .addField('serverinfo', 'Server info')
    .addField('botinfo', 'Bot info')
    .addField(`ping`, 'It says how fast the bot responds')
    .setThumbnail(message.guild.avatarURL)
    .setFooter('Creator xarazzert')
    .setColor('#cc1414')
    message.channel.send(embed)
}
exports.help = {
    name: 'help'
}