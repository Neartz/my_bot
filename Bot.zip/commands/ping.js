exports.run = (client, message, args) => {
    const Discord = require('discord.js')
    var embed = new Discord.RichEmbed()
    .setAuthor(client.user.username, client.user.avatarURL )
    .setTitle('Pong!')
    .setDescription(`Latency **${Math.floor(client.ping)} ms⏰**`)
    .setColor('#cc1414')
    .setFooter('Creator Xarazzert')
    message.channel.send(embed)
}
exports.help = {
    name: 'ping'
}