const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

  let cleanedEmbed = new Discord.RichEmbed()
  .setDescription("**Action `Purge` successfully completed!**")
  .setColor("#cc1414")
  .setFooter('Creator Xarazzert')
  .addField("**Was deleted**:", `**${args[0]} messages.✉**`);

  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("Not enough rights.");
  if(!args[0]) return message.channel.send("Specify the amount!");
  message.channel.bulkDelete(args[0]).then(() => {
  message.channel.send(cleanedEmbed).then(msg => msg.delete(3000));
});
}
module.exports.help = {
  name: "purge"
}