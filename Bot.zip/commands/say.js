const Discord = require('discord.js');

module.exports.run = async (bot, message, args) => {
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("Not enough rights.");
  const sayMessage = args.join(" ");

  message.delete().catch(O_o => {});

  message.channel.send(sayMessage);

}